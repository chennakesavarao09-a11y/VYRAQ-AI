"""Grounded interview question and answer preparation service."""

from __future__ import annotations

from langchain_core.language_models.chat_models import BaseChatModel
from pydantic import BaseModel, Field

from ai.llm_factory import invoke_structured_json
from modules.job_analyzer import JobAnalysisResult
from modules.resume_analyzer import ResumeAnalysisResult
from modules.skill_gap import SkillGapResult


class InterviewQuestionItem(BaseModel):
    """Single interview question with rationale and sample answer points."""

    category: str  # technical | role_specific | resume_based | hr
    question: str
    difficulty: str = "Medium"
    target_skill_or_topic: str = ""
    rationale: str = ""
    key_answer_points: list[str] = Field(default_factory=list)
    sample_answer: str = ""


class InterviewPrepResult(BaseModel):
    """Grouped interview preparation questions grounded in resume, JD, and skill gaps."""

    technical_questions: list[InterviewQuestionItem] = Field(default_factory=list)
    role_specific_questions: list[InterviewQuestionItem] = Field(default_factory=list)
    resume_based_questions: list[InterviewQuestionItem] = Field(default_factory=list)
    hr_questions: list[InterviewQuestionItem] = Field(default_factory=list)


def generate_interview_questions(
    resume_analysis: ResumeAnalysisResult | dict,
    job_analysis: JobAnalysisResult | dict,
    skill_gap: SkillGapResult | dict,
    llm: BaseChatModel,
    rag_context: str = "",
) -> InterviewPrepResult:
    """Generate categorized interview questions grounded in resume, JD, existing and missing skills."""
    r_obj = (
        resume_analysis
        if isinstance(resume_analysis, ResumeAnalysisResult)
        else ResumeAnalysisResult.model_validate(resume_analysis)
    )
    j_obj = (
        job_analysis
        if isinstance(job_analysis, JobAnalysisResult)
        else JobAnalysisResult.model_validate(job_analysis)
    )
    g_obj = (
        skill_gap
        if isinstance(skill_gap, SkillGapResult)
        else SkillGapResult.model_validate(skill_gap)
    )

    system_prompt = (
        "You are a senior hiring manager and interview coach. Generate realistic, insightful "
        "interview questions grounded specifically in the candidate's resume, the target job "
        "description, existing skills, and missing skills. Include clear key answer points and a "
        "strong sample answer for every question. Return ONLY valid JSON."
    )

    rag_section = f"\nRETRIEVED RAG EVIDENCE:\n{rag_context}\n" if rag_context else ""

    user_prompt = f"""Generate tailored interview questions across 4 categories (3 questions per category).

CANDIDATE PROFILE:
- Summary: {r_obj.candidate_summary}
- Existing Skills: {r_obj.detected_skills}
- Experience Highlights: {r_obj.experience_highlights}

TARGET JOB:
- Role: {j_obj.job_title} ({j_obj.seniority_level})
- Responsibilities: {j_obj.key_responsibilities}
- Required Skills: {j_obj.required_skills}

SKILL GAPS:
- Available Skills: {g_obj.available_skills}
- Missing Skills: {g_obj.missing_skills}
{rag_section}
Return JSON with EXACT keys:
{{
  "technical_questions": [
    {{
      "category": "technical",
      "question": "...",
      "difficulty": "Easy | Medium | Hard",
      "target_skill_or_topic": "specific skill or missing skill",
      "rationale": "why this question is asked based on JD/gaps",
      "key_answer_points": ["bullet 1", "bullet 2", "bullet 3"],
      "sample_answer": "concise strong sample answer"
    }}
  ],
  "role_specific_questions": [...],
  "resume_based_questions": [...],
  "hr_questions": [...]
}}"""

    return invoke_structured_json(llm, system_prompt, user_prompt, InterviewPrepResult)
